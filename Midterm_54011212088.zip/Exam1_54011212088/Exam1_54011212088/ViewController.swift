//
//  ViewController.swift
//  Exam1_54011212088
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inputName: UITextField!
    @IBOutlet weak var inputMid: UITextField!
    @IBOutlet weak var inputFinal: UITextField!
    @IBOutlet weak var inputBonus: UITextField!
    @IBOutlet weak var outputLBName: UILabel!
    @IBOutlet weak var outputLBScored: UILabel!
    @IBOutlet weak var outputLBGrade: UILabel!
    
    
    var Name = ""
    var Midterm = 0.0
    var Final = 0.0
    var Bonus = 0.0
    var SumGrade = 0.0
    var Grade = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Calculate(sender: AnyObject) {
            data()
        SumGrade = Midterm + Final + Bonus
        Calculate_Grede(SumGrade)
    
        outputLBName.text = "Name : \(Name)"
        outputLBScored.text = "Scored : \(SumGrade)"
        outputLBGrade.text = "Grade : \(Grade)"
        
    }
    
    func data(){
        Name = inputName.text
        Midterm = Double((inputMid.text as NSString).doubleValue)
        Final = Double((inputFinal.text as NSString).doubleValue)
        Bonus = Double((inputBonus.text as NSString).doubleValue)
        
    }
    
    func Calculate_Grede(print:Double){
        if print >= 80{
            Grade = "A"
        }
        else if print >= 74{
            Grade = "B+"
        }
        else if print >= 68{
            Grade = "B"
        }
        else if print >= 62{
            Grade = "C+"
        }
        else if print >= 56{
            Grade = "C"
        }
        else if print >= 50{
            Grade = "D+"
        }
        else if print >= 44{
            Grade = "D"
        }
        else if SumGrade < ((SumGrade - 5)/100) {
            Grade = "F"
        }
        else {
            Grade = "F"
        }
    }

}

